# Demo Files
- `demo-1.0.jar` - Version 1 of demo app
- `demo-2.0.jar` - Version 2 of demo app
- `demo.yml` - Configuration for Kubernetes Deployment and LoadBalancer Service
- `dockerfile` - dockerfile for image of demo app to run on Kubernetes
- `pom.xml` - Maven build file
- `src` - Java source files for demo app
