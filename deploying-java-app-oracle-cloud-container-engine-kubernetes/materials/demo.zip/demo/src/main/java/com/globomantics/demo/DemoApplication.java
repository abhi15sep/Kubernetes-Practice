package com.globomantics.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DemoApplication {

	//for demo purposes only to see different requests handled by instances of the application
	static int counter = 1;
	
	@RequestMapping("/")
	public String demoEndpoint() {

		return "Hello from application " + counter++;
		//return "Goodbye from application " + counter++;
	}
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
