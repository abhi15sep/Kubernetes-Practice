# Demo Files
- `app.py` - Source for demo app
- `demo.yml` - Configuration for Kubernetes Deployment and LoadBalancer Service
- `dockerfile` - dockerfile for image of demo app to run on Kubernetes
- `requirements.txt` - For installing Flask when building docker image
